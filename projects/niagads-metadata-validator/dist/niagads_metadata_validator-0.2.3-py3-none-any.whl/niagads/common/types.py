from enum import auto
from typing import Annotated, Union

from niagads.enums.core import CaseInsensitiveEnum
from niagads.utils.regular_expressions import RegularExpressions
from pydantic import Field

T_PubMedID = Annotated[str, Field(pattern=RegularExpressions.PUBMED_ID)]
T_DOI = Annotated[str, Field(pattern=RegularExpressions.DOI)]
T_Gene = Annotated[str, Field(pattern=RegularExpressions.GENE)]
T_VariantID = Annotated[str, Field(pattern=RegularExpressions.POSITIONAL_VARIANT_ID)]
T_RefSNP = Annotated[str, Field(pattern=RegularExpressions.REF_SNP_ID)]

PrimitiveType = Union[str, int, float, bool, None]


class ProcessStatus(CaseInsensitiveEnum):
    """
    Enum representing the overall outcome of a process or workflow step.

    - SUCCESS: Process completed successfully.
    - FAIL: Process failed.
    - IN_PROGRESS: Process is currently running.
    """

    SUCCESS = auto()
    FAIL = auto()
    IN_PROGRESS = auto()


# placed here to avoid creating a dependency in the `database` component on the `etl` component
class ETLOperation(CaseInsensitiveEnum):
    """
    Type of ETL operation:
    - LOAD: Insert new or Update existing records.
    - UPDATE: Update existing records.
    - DELETE: Delete records.
    - INSERT: Insert new records.
    - SKIP: Skip a record
    """

    INSERT = auto()
    UPDATE = auto()
    LOAD = auto()
    DELETE = auto()
    SKIP = auto()

    def past_tense(self):
        if self == ETLOperation.SKIP:
            return "SKIPPED"

        if self.name.endswith("E"):
            return f"{self.name}D"

        return f"{self.name}ED"
