from typing import Optional, Set

from niagads.common.models.base import CustomBaseModel
from niagads.common.reference.xrefs.data_sources import (
    Consortia,
    NIAGADSResources,
    ThirdPartyResources,
)
from niagads.common.types import T_PubMedID
from niagads.utils.regular_expressions import RegularExpressions
from niagads.utils.string import matches
from pydantic import Field, computed_field, field_validator


class Provenance(CustomBaseModel):
    data_source: str = Field(
        default=NIAGADSResources.NIAGADS_DSS.name,
        title="Data Source",
        description="original file data source",
    )
    accession: Optional[str] = Field(
        default=None,
        title="Accession",
        description="accession identifier in original data source; may be parent accession if track is part of a collection (e.g., NIAGADS DSS dataset accession)",
    )  # have to control required status in ETL (FILER vs NIAGADS)

    release_date: Optional[str] = Field(
        default=None,
        title="Release Date",
        json_schema_extra={"exclude_from_embeddings": True},
    )

    release_version: Optional[str] = Field(
        default=None,
        title="Release Version",
        json_schema_extra={"exclude_from_embeddings": True},
    )

    download_date: Optional[str] = Field(
        default=None,
        title="Download Date",
        json_schema_extra={
            "is_filer_annotation": True,
            "exclude_from_embeddings": True,
        },
    )

    download_url: Optional[str] = Field(
        default=None,
        title="Download URL",
        exclude=True,
        json_schema_extra={
            "is_filer_annotation": True,
            "exclude_from_embeddings": True,
        },
    )
    consortium: Optional[Set[Consortia]] = Field(
        default=None,
        title="Consortium",
        description=f"collaborative partnership",
    )

    study: Optional[str] = Field(
        default=None,
        title="Study",
        json_schema_extra={"is_filer_annotation": True},
    )

    project: Optional[str] = Field(
        default=None,
        title="Project",
        description=(
            "organizational unit that may include multiple studies and datasets "
            "under a common goal, funding source, or program. (e.g., ADSP FunGen xQTL)"
        ),
    )
    attribution: Optional[str] = Field(
        default=None,
        pattern=RegularExpressions.ATTRIBUTION,
        title="Attribution",
        description="Human-readable author citation for primary publication (or PI and year if no publication).  Must match author-date citation format, e.g., Smith 2006 or Smith et al. 2006",
    )  # FIXME: for FILER allow to be None

    pubmed_id: Optional[Set[T_PubMedID]] = Field(default=None, title="PubMed ID")

    doi: Optional[Set[str]] = Field(
        default=None, title="DOI", json_schema_extra={"exclude_from_embeddings": True}
    )

    @field_validator("doi", mode="after")
    def validate_doi(cls, values: Set[str]):
        """create validator b/c Pydantic does not support patterns w/lookaheads"""
        if values is not None and len(values) > 0:
            for v in values:
                if not matches(RegularExpressions.DOI, v):
                    raise ValueError(
                        f"Invalid DOI format: {v}. Please provide a valid DOI."
                    )
        return values

    @computed_field
    @property
    def data_source_url(self) -> str:
        # dsKey: str = (
        #    f"{self.data_source}|{self.release_version}"
        #    if self.release_version is not None
        #    else self.data_source
        # )
        # removed versioning from the data source URLs; incorrect legacy from FILER
        dsKey = self.data_source
        try:
            return ThirdPartyResources(dsKey).value
        except:
            try:
                return NIAGADSResources(dsKey).value
            except:
                raise ValueError(
                    f"Data source URL not found for {dsKey}. Please add to data_sources.ThirdParty."
                )


class FileProperties(CustomBaseModel):
    file_name: str = Field(
        title="File Name",
    )
    url: Optional[str] = Field(
        default=None,
        title="URL",
        json_schema_extra={"is_filer_annotation": True},
    )
    md5sum: str = Field(pattern=RegularExpressions.MD5SUM, title="MD5 Sum")

    bp_covered: Optional[int] = Field(
        default=None,
        title="Base Pairs Covered",
        json_schema_extra={"is_filer_annotation": True},
    )
    num_intervals: Optional[int] = Field(
        default=None,
        title="Number of Intervals",
        json_schema_extra={"is_filer_annotation": True},
    )
    file_size: int = Field(title="File Size")

    file_format: Optional[str] = Field(
        default=None,
        title="File Format",
        json_schema_extra={"is_filer_annotation": True},
    )
    file_schema: Optional[str] = Field(
        default=None,
        title="File Schema",
        json_schema_extra={"is_filer_annotation": True},
    )
    release_date: Optional[str] = Field(
        default=None,
        title="Release Date",
        json_schema_extra={"is_filer_annotation": True},
    )  # Field(exclude=True)
