"""
This module provides a CSVFileParser class for parsing CSV files with additional functionality.

The CSVFileParser inherits from AbstractFlatfileParser and provides methods to infer delimiters,
convert CSV data to pandas data frame or JSON, and parse lines into records. The iterator behavior
is inherited from the parent class and utilizes the `parse_line` method to determine the output.

Iterator Behavior:
- With a header: Each iteration returns a dictionary where keys are column names and
    values are the corresponding data.
- Without a header: Each iteration returns a list of values.

Iterator Usage Example:

```python
from niagads.csv_parser.core import CSVFileParser

parser = CSVFileParser("example.csv", header=True)
for record in parser:
    print(record)
```
"""

import json

from csv import Sniffer, Error as CSVError
from typing import Optional
from niagads.exceptions.core import FileFormatError
from niagads.flatfile.base import AbstractFlatfileParser
from pandas import read_csv, DataFrame

from niagads.utils.dict import convert_str2numeric_values
from niagads.utils.pandas import strip_df

LIST_DELIMITERS = ["|", "/", ";", "="]


class CSVFileParser(AbstractFlatfileParser):
    """
    Parser for CSV files with additional functionality:

    - Infer delimiter automatically.
    - Convert CSV data to JSON using pandas.

    Attributes:
        file (str): Path to the CSV file.
        header (bool): Indicates if the file contains a header row.
        delimiter (str): Delimiter used in the CSV file. If None, it will be inferred.
        encoding (str): File encoding. Defaults to "utf-8".
        debug (bool): Debug mode flag.
        verbose (bool): Verbose mode flag.
    """

    def __init__(
        self,
        file: str,
        header: Optional[list[str]] = None,
        delimiter: Optional[str] = None,
        encoding="utf-8",
        debug: bool = False,
        verbose: bool = False,
        logger=None,
    ):
        super().__init__(
            file, encoding=encoding, debug=debug, verbose=verbose, logger=logger
        )

        self.__delimiter = delimiter
        self.__na = None  # missing value string representation
        self.__header = header  # flag indicating whether file has a header
        self.__header_fields = None

    def header_fields(self, values: list[str]):
        """only necessary to customize header for iterator, w/pandas can define header fields
        directly using `header` kwarg when calling `to_pandas_df` or `to_json`"""
        self.__header_fields = values

    def na(self, value: str):
        """
        Fill NA values with the specified value when using pandas conversions.

        Args:
            value (str): Value to fill (e.g., 'NULL', 'NA', '.').
        """
        self.__na = value

    def to_json(self, transpose=False, return_str=False, **kwargs):
        """
        Convert the CSV file to JSON format.

        Args:
            transpose (bool, optional): Whether to transpose the worksheet. Defaults to False.
            return_str (bool, optional): Whether to return a JSON string instead of an object. Defaults to False.
            **kwargs (optional): arguments to pass to `pandas` `read_csv` see
                (see https://pandas.pydata.org/docs/reference/api/pandas.read_excel.html))

        Returns:
            str or dict: JSON string if `return_str` is True, otherwise a JSON object.
        """

        # orient='records' returns indexes; e.g. [index: {row data}] so need to extract the values
        json_str = self.to_pandas_df(transpose, **kwargs).to_json(orient="records")

        # convert strings to numeric so can do typing validation
        json_obj = json.loads(json_str)
        if isinstance(json_obj, list):
            json_obj = [convert_str2numeric_values(r) for r in json.loads(json_str)]
        else:
            json_obj = convert_str2numeric_values(json_obj)

        return json.dumps(json_obj) if return_str else json.loads(json_str)

    def sniff(self, bytes: int = 1024):
        """
        Infer the delimiter used in the CSV file by analyzing its content.

        Args:
            bytes (int, optional): Number of bytes to read for delimiter inference. Defaults to 1024.

        Returns:
            str: Inferred delimiter.

        Raises:
            FileFormatError: If the delimiter cannot be determined.
        """
        invalid_delimiter = None
        try:
            if self.__delimiter is not None:
                return self.__delimiter
            else:
                with open(self._file, "r", encoding="utf-8", errors="ignore") as fh:
                    sample = fh.read(bytes)

                delimiter: str = Sniffer().sniff(sample).delimiter
                if delimiter in LIST_DELIMITERS or delimiter.isalnum():
                    invalid_delimiter = delimiter
                    delimiter = (
                        Sniffer().sniff(sample, delimiters=[",", "\t"]).delimiter
                    )

                # so repeated calls don't have to sniff again
                self.__delimiter = delimiter
                return delimiter

        except CSVError as err:
            if bytes < 4096:  # try a larger section of the file
                return self.sniff(bytes=4096)
            if invalid_delimiter is not None:
                raise FileFormatError(
                    f"Invalid delimiter detected: {invalid_delimiter!r}."
                )
            raise FileFormatError(
                "Unable to determine file delimiter."
                "File may have inconsistent numbers of columns, sparse data, "
                "or use inconsistent delimiters."
            ) from err

    def to_pandas_df(self, transpose=False, **kwargs) -> DataFrame:
        """
        Convert the CSV file to a pandas DataFrame.

        Args:
            transpose (bool, optional): Whether to transpose the worksheet. Defaults to False.
            **kwargs: Additional arguments passed to pandas `read_csv`.

        Returns:
            DataFrame: CSV data in DataFrame format.
        """
        if kwargs is None:
            kwargs = {}

        if "delimiter" not in kwargs:
            kwargs["delimiter"] = self.sniff()

        if "header" not in kwargs:
            if self.__header_fields is not None:
                kwargs["header"] = self.__header_fields
            elif self.__header is None:
                kwargs["header"] = None
            else:
                kwargs["header"] = 0

        # raise error if False
        df: DataFrame = read_csv(self._file, **kwargs)
        if self.__na is not None:
            df.fillna(self.__na)
        return strip_df(df.T) if transpose else strip_df(df)

    # abstract base class overrides
    def is_ignored_line(self, line: str, line_number: int) -> bool:
        if self.__header and line_number == 1:
            self.__header_fields = [v.strip() for v in line.split(self.sniff())]
            return True
        stripped = line.strip()
        return stripped == ""

    def parse_line(self, line: str):
        """Parse one non-ignored line into a record."""
        values = [v.strip() for v in line.split(self.sniff())]
        if self.__header or self.__header_fields is not None:
            return dict(zip(self.__header_fields, values))
        else:
            return values
