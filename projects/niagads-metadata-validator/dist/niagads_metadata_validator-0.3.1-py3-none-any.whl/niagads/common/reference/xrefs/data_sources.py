from enum import auto
from typing import List
from niagads.enums.core import CaseInsensitiveEnum


class Consortia(CaseInsensitiveEnum):
    IGAP = auto()  # "International Genomics of Alzheimer's Project"
    ADGC = auto()  # "Alzheimer's Disease Genetics Consortium"
    ADSP = auto()  # "Alzheimer's Disease Sequencing Project"

    def __str__(self):
        return self.name

    @classmethod
    def list(cls, to_lower: bool = False, return_enum_names: bool = True) -> List[str]:
        return super().list(to_lower=False, return_enum_names=return_enum_names)


class NIAGADSResources(CaseInsensitiveEnum):
    NIAGADS = "https://www.niagads.org"
    NIAGADS_DSS = "https://dss.niagads.org"
    ADVP = "https://advp.niagads.org"
    FILER = "https://tf.lisanwanglab.org/FILER"
    FILER_SERVICE_URL = "https://tf.lisanwanglab.org/FILER2/"
    FILER_DOWNLOAD_URL = "https://tf.lisanwanglab.org/GADB"
    GENOMICSDB = "https://www.niagads.org/genomics"

    @classmethod
    def _missing_(cls, value: str):
        key = value.upper().replace("-", "_").replace(" ", "_")
        try:
            return cls.__members__[key]
        except ValueError as err:
            raise err


class ThirdPartyResources(CaseInsensitiveEnum):
    PUBMED = "https://pubmed.ncbi.nlm.nih.gov"
    PUBMED_API = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id="
    DASHR2 = "http://dashr2.lisanwanglab.org/index.php"
    ENCODE = "https://www.encodeproject.org"
    EPIMAP = "https://compbio.mit.edu/epimap/"
    FANTOM5 = "http://fantom.gsc.riken.jp/5/"
    FANTOM5_SLIDEBASE = "http://slidebase.binf.ku.dk"
    FACTORBOOK = "https://genome.ucsc.edu/index.html"
    FACTORBOOK_LIFTED = "https://genome.ucsc.edu/index.html"
    INFERNO = "http://inferno.lisanwanglab.org/index.php"
    GTEX = "https://gtexportal.org"
    HOMER = "http://homer.ucsd.edu/homer"
    ROADMAP = "http://www.roadmapepigenomics.org"
    TARGETSCAN_V7P2 = "http://www.targetscan.org/vert_72"
    TARGETSCAN = "https://www.targetscan.org"
    ENSEMBL = "https://www.ensembl.org"
    CEEHRC = "http://epigenomesportal.ca/ihec"
    IHEC_EPIGENOMES = "https://ihec-epigenomes.org/"
    ONE_K_GENOME_PHASE3 = "https://www.internationalgenome.org/category/phase-3"
    THREE_DGENOME = "https://3dgenome.fsm.northwestern.edu"
    BLUEPRINT = "https://ihec-epigenomes.org/research/projects/blueprint/"
    EPIHK = "https://epihk.org/"
    CADD = "https://cadd.gs.washington.edu/"
    UCSC = "https://genome.ucsc.edu/"
    DBSNP = "https://www.ncbi.nlm.nih.gov/snp/"
    EQTL_CATALOGUE = "https://www.ebi.ac.uk/eqtl/"
    GENCODE = "https://www.gencodegenes.org/"
    GWAS_CATALOG = "https://www.ebi.ac.uk/gwas/"
    REFSEQ = "https://www.ncbi.nlm.nih.gov/refseq/"
    TF_FOOTPRINT_ATLAS = "https://doi.org/10.1016/j.celrep.2020.108029"
    KEGG = "https://www.kegg.jp"

    FOUR_DNUCLEOME = "https://data.4dnucleome.org/"
    ATACDB = "https://bio.liclab.net/ATACdb/"
    OSF = "https://osf.io"
    GEO = "https://www.ncbi.nlm.nih.gov/geo"

    # PROBLEMATIC FILER
    # --- defunct
    FOUR_DGENOME = "https://4dgenome.research.chop.edu/"

    # --methods
    HIPPIE2 = "https://bitbucket.org/wanglab-upenn/HIPPIE2"

    # --papers
    JAVIERRE = "https://osf.io/u8tzp/"
    JUNG = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE86189"
    NASSER = "https://www.engreitzlab.org/resources"
    NOTT = "http://homer.ucsd.edu/iholtman/Nuclei_project/interaction/MAPS/"
    SONG = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE113483"

    def __replace_leading_digit_with_word(s: str) -> str:
        digit_map = {
            "1": "ONE",
            "2": "TWO",
            "3": "THREE",
            "4": "FOUR",
            "5": "FIVE",
            "6": "SIX",
            "7": "SEVEN",
            "8": "EIGHT",
            "9": "NINE",
        }

        if s and s[0] in digit_map:
            return f"{digit_map[s[0]]}_{s[1:]}"
        return s

    @classmethod
    def _missing_(cls, value: str):
        """handle versions; e.g., DASHR2|small_RNA_Genes" -> DASHR2_SMALL_RNA_GENES"""
        key = cls.__replace_leading_digit_with_word(
            value.upper().replace("|", "_").replace("-", "_").replace(" ", "_")
        )
        if key.startswith("ROADMAP"):
            key = "ROADMAP"
        try:
            return cls.__members__[key]
        except ValueError as err:
            raise err
