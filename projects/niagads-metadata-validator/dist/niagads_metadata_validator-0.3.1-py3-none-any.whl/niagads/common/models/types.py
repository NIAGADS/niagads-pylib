from typing import Dict, Optional
from niagads.exceptions.core import ValidationError
from pydantic import BaseModel, Field, model_validator


class Range(BaseModel):
    start: int = Field(title="Start")
    end: Optional[int] = Field(default=None, title="End")
    inclusive_end: Optional[bool] = Field(default=False, exclude=True)

    def model_post_init(self, __context):
        if self.end is None:
            self.end = self.start

    @model_validator(mode="before")
    @classmethod
    def validate(self, range: Dict[str, int]):
        if "end" in range:
            if range["start"] > range["end"]:
                raise ValidationError(
                    f"Invalid Range: {range['start']} > {range['end']}"
                )
        return range

    def __str__(self):
        return f"{self.start}-{self.end}"

    def to_range_string(self):
        end_brace = "]" if self.inclusive_end else ")"
        return f"[{self.start},{self.end}{end_brace}"

    def bracket_notation(self):
        return f"[{self.start}, {self.end}{']' if self.inclusive_end else ')'}"

    def validate_span_within_limit(self, max_span: int):
        if self.end is None:
            raise RuntimeError("Range.end is None, cannot validate range size.")

        return self.end - self.start <= max_span
