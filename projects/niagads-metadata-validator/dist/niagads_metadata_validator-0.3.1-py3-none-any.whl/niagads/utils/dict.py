"""library of object / dictionary / hash manipulation functions"""

import json
from typing import Union
import warnings
from collections import abc
from types import SimpleNamespace
from copy import deepcopy
from functools import reduce

from niagads.utils.string import (
    is_bool,
    is_null,
    is_numeric,
    to_bool,
    to_json,
    to_number,
)
from niagads.utils.list import all_elements_are_none as __list_is_none


def deep_merge(a: dict, b: dict) -> dict:
    """
    Recursively merge two dictionaries, combining their keys and values.
    For each key:
        - If the value in both a and b is a dict, merge them recursively.
        - Otherwise, the value from b overrides the value from a.
    Returns a new merged dictionary, does not modify inputs.

    Args:
        a (dict): The base dictionary.
        b (dict): The dictionary with overriding values.

    Returns:
        dict: The deeply merged dictionary.
    """
    out = dict(a or {})
    for k, v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def nested_get(dictionary, keys, default=None):
    """Retrieve a nested value using a sequence of keys.

    `keys` may be an iterable of individual keys or a dot-separated string.
    If a key is missing or an intermediate value cannot be indexed, returns
    ``default`` instead.

    Args:
        dictionary (dict): The dictionary or mapping to search.
        keys (Iterable or str): The keys to follow in order, or a dot-separated
            key path.
        default: The value to return when the nested lookup fails. Defaults to
            None.

    Returns:
        The value found at the nested key path, or ``default`` if the lookup
        fails.

    Examples:
        >>> nested_get({"user": {"name": "Ada"}}, ["user", "name"])
        'Ada'
        >>> nested_get({"user": {"name": "Ada"}}, "user.name")
        'Ada'
        >>> nested_get({"user": {}}, ["user", "age"], default=0)
        0
    """

    if isinstance(keys, str):
        keys = keys.split(".")

    try:
        # Successively navigates keys; catches missing dicts or wrong types
        return reduce(lambda d, k: d[k], keys, dictionary)
    except (KeyError, TypeError):
        return default


def promote_nested(obj: dict, attributes=None, modify_in_place: bool = False):
    """Promote nested dictionaries to the top level of a dictionary.

    If `attributes` is provided, only nested dicts whose keys are in `attributes` are promoted.
    Otherwise, all nested dicts are promoted. When `modify_in_place` is True, the original
    object is modified; otherwise, a new object is returned.

    Example:
        {"A": {"B": 1, "C": 2}, "D": 3} -> {"B": 1, "C": 2, "D": 3}

    Args:
        obj (dict): The dictionary to promote nested dicts from.
        attributes (list or None, optional): List of keys to promote if their values are dicts.
            If None, all nested dicts are promoted. Defaults to None.
        modify_in_place (bool): If True, modifies the original object. If False, returns a new object.

    Returns:
        dict or True: The updated dictionary if not modifying in place, otherwise True for success.
    """
    new_obj = deepcopy(obj) if not modify_in_place else obj
    if attributes is not None:
        fields = [
            k for k, v in new_obj.items() if isinstance(v, dict) and k in attributes
        ]
    else:
        fields = [k for k, v in new_obj.items() if isinstance(v, dict)]

    for f in fields:
        new_obj.update(obj.pop(f, None))

    return new_obj if not modify_in_place else True


def all_values_are_none(dictObj: dict):
    """returns true if all dict is empty or values are none"""
    return __list_is_none(dictObj.values())


def rename_key(
    dictObj: dict, oldKey: str, newKey: str, ordered: bool = False
):  # note does not preserve python3+ ordering
    """
    rename dict key

    Args:
        dictObj (dict): the dictionary object to update
        oldKey (str): old key
        newKey (str): new key
        ordered (bool, optional): keep ordering; slower. Defaults to False.

    Returns:
        updated dict object
    """
    if ordered:
        return {newKey if k == oldKey else k: v for k, v in dictObj.items()}

    dictObj[newKey] = dictObj.pop(oldKey)
    return dictObj


def __prune(value, prune):
    """
    wrapper so we only test strings for na values
    note: does not treat empty lists or objs as null
    """
    if value is None:
        return True
    if isinstance(value, str):
        return is_null(value, naIsNull=True) or value in prune
    return False


def prune(dictObj: dict, remove_nulls: bool = True, prune: list = []):
    """
    remove null entries from dict and entries whose value matches items in `prune`

    Args:
        dictObj (dict): the dictionary/hash
        removeNulls (bool, optional): flag indicating whether to remove null values.  Defaults to True.
        prune (list, optional): list of additional values to prune. Defaults to an empty list.

    Returns:
        cleaned up dict
    """
    return {
        key: value
        for key, value in dictObj.items()
        if (remove_nulls and value is not None and not __prune(value, prune))
    }


def print_dict(dictObj, pretty=True):
    """pretty print a dict / JSON object"""
    if isinstance(dictObj, SimpleNamespace):
        return dictObj.__repr__()
    return (
        json.dumps(dictObj, indent=4, sort_keys=True) if pretty else json.dumps(dictObj)
    )


def get(obj, attribute, default=None, errorAction="fail"):
    """
    retrieve attribute if in dict

    Args:
        obj (dict): dictionary object to query
        attribute (string): attribute to return
        default (obj): value to return on KeyError. Defaults to None
        errorAction (string, optional): fail or warn on KeyError. Defaults to False

    Returns:
        the value of the attribute or the supplied `default` value if the attribute is missing
    """
    if errorAction not in ["warn", "fail", "ignore"]:
        raise ValueError(
            "Allowable actions upon a KeyError are `warn`, `fail`, `ignore`"
        )

    try:
        return obj[attribute]
    except KeyError as err:
        if errorAction == "fail":
            raise err
        elif errorAction == "warn":
            warnings.warn("KeyError:" + err, RuntimeWarning)
            return default
        else:
            return default


def drop_nulls(obj):
    """find nulls and remove from the object"""
    if isinstance(obj, list):
        return ValueError(
            "Use drop_nulls from the list package to remove nulls from a list/array"
        )
    if isinstance(obj, dict):
        return {k: v for k, v in obj.items() if v}


def deep_update(d, u):
    """
    deep update a nested dict
    based on https://stackoverflow.com/questions/3232943/update-value-of-a-nested-dictionary-of-varying-depth/60321833
    answer: https://stackoverflow.com/a/3233356
    TODO: may not handle all variations

    Args:
        d (dict obj): source dict to be updated
        u (dict obj): overrides/updates to be made

    Returns:
        the deep updated source dict
    """
    for k, v in u.items():
        if isinstance(v, abc.Mapping):
            d[k] = deep_update(d.get(k, {}), v)
        else:
            d[k] = v
    return d


def convert_str2numeric_values(cdict: dict, nanAsStr=True, infAsStr=True):
    """converts numeric values in dictionary stored as strings
    to numeric

    Args:
        cdict (dict obj): dict bject to convert
        nanAsStr (bool, optional): treat NaN/nan/NAN as string?
        infAsStr (bool, optional): treat inf/INF as string?

    Returns:
        updated dict object
    """
    value: Union[str, float, bool]
    for key, value in cdict.items():
        if value is None:
            continue
        if str(value).upper() == "NAN" and nanAsStr:
            # is_float test will be true for NaN/NAN/nan/Nan etc
            continue
        if "inf" in str(value).lower() and infAsStr:
            # is_float test will be true for Infinity / -Infinity
            continue
        if is_bool(value, int_as_bool=False):
            cdict[key] = to_bool(value)
        elif is_numeric(value):
            cdict[key] = to_number(value)

    return cdict


def size(obj, n=0):
    """
    recursively find size (number of elements) in a potentially nested dict
    after https://www.tutorialspoint.com/How-to-count-elements-in-a-nested-Python-dictionary
    """
    for key in obj:
        if isinstance(obj[key], dict):
            n = size(obj[key], n + 1)
        else:
            n += 1
    return n


def info_string_to_dict(infoStr: str) -> dict:
    """
    Convert an string (e.g., "DP=100;AF=0.5;DB") into a dictionary.
    Flags (like DB) will have value True.
    """
    infoObj = {}
    if infoStr is None or infoStr == ".":
        raise ValueError("Cannot convert null-valued info string")
    for item in infoStr.split(";"):
        if "=" in item:
            key, value = item.split("=", 1)
            infoObj[key] = to_json(
                value
            )  # will convert almost everything to correct type
        else:
            infoObj[item] = True  # Flag field
    return infoObj
