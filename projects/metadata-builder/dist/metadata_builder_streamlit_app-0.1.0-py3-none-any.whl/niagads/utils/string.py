"""string
The `string` module provides a library of
string manipulation functions, converters and
value testers
"""

import hashlib
import json
import re
import uuid
from datetime import datetime
from typing import List, Union

from dateutil.parser import parse as parse_date
from typing_extensions import deprecated


def jaccard_word_similarity(a: str, b: str) -> float:
    """
    Computes Jaccard similarity between two strings by comparing sets of unique
    words. (see https://en.wikipedia.org/wiki/Jaccard_index)

    The function splits each string into words, converts them to lowercase, and
    forms sets of unique words. It then calculates the Jaccard similarity as the
    ratio of the size of the intersection to the size of the union of these sets.
    Word order, duplicates, and semantic meaning are ignored.

    Args:
        a (str): First string to compare.
        b (str): Second string to compare.

    Returns:
        float: Jaccard similarity score between 0.0 and 1.0, representing the
            overlap of unique words.
    """
    set_a = set(a.lower().split())
    set_b = set(b.lower().split())
    intersection = set_a & set_b
    union = set_a | set_b
    return len(intersection) / len(union) if union else 0.0


def generate_uuid(value: str):
    """Generates a unique ID (UUID) from a string using SHA-256 hashing.

    Args:
        value(str): The string to generate a unique ID from.

    Returns:
        A UUID object representing the unique ID.
    """
    hashedString = hashlib.sha256(value.encode()).hexdigest()
    return uuid.uuid5(uuid.NAMESPACE_DNS, hashedString)


def blake2b_hash(value: str, size: int = 20):
    """hash a string using blake2b hashing.

    Args:
        value(str): The string to generate a unique ID from.
        size (str): digest size

    Returns:
        A UUID object representing the unique ID.
    """
    hashedString = hashlib.blake2b(value.encode("utf-8"), digest_size=size).hexdigest()
    return hashedString


@deprecated("use `list_utils.find_in_list` instead")
def string_in_list(value: str, array: List[str], ignoreCase=False):
    pass


def eval_null(value: str, naIsNull=False):
    """
    checks to see if value is NULL / None or equivalent

    Args:
        value (str): value to evaluate
        naIsNull (boolean, optional): NA is considered null.  Default to False

    Returns:
        None if null value, else value
    """
    if value is not None and is_null(value, naIsNull=naIsNull):
        return None
    return value


def dict_to_info_string(obj):
    """wrapper for dict_to_string (semantics )
    FIXME: in string utils to avoid circular imports"""
    return dict_to_string(obj, ".")


def dict_to_string(obj, null_str, delimiter=";"):
    """translate dict to attr=value; string list
    FIXME: in string utils to avoid circular imports
    """
    pairs = [k + "=" + xstr(v, null_str=null_str) for k, v in obj.items()]
    pairs.sort()
    return delimiter.join(pairs)


def reverse(s):
    """reverse a string
    see https://www.w3schools.com/python/python_howto_reverse_string.asp"""
    return s[::-1]


def truncate(s, length):
    """
    if string s is > length, return truncated string
    with ... added to end
    """
    return (s[: (length - 3)] + "...") if len(s) > length else s


def xstr(value, null_str="", falseAsNull=False, dictsAsJson=True):
    """
    wrapper for str() that handles Nones,
    lists, and dict objects

    Args:
        value (obj): obj / type to be converted to string
        null_str (str, optional): value to used to indicate NULL/None. Defaults to "".
        falseAsNull (bool, optional): treat `False` as None. Defaults to False.
        dictsAsJson (bool, optional): convert dicts to JSON, otherwise generates
        an INFO string (semi-colon delimited key=value pairs). Defaults to True.
        if null_str is "" and dictAsJson=False, '.' will be used in the info string
        for None values

    Returns:
        value in string format
    """
    if value is None:
        return null_str

    if isinstance(value, list):
        if len(value) == 0:
            return null_str
        else:
            return ",".join(
                [xstr(v, null_str, falseAsNull, dictsAsJson) for v in value]
            )

    if isinstance(value, dict):
        if bool(value):
            if dictsAsJson:
                return json.dumps(value)
            else:
                return dict_to_string(value, null_str=".")
        else:
            return null_str

    if falseAsNull and isinstance(value, bool):
        if value is False:
            return null_str
        else:
            return str(value)

    if is_date(value):
        return to_date(value, returnStr=True)

    return str(value)


# FIXME: try/catch for non numeric types
def to_date(value, pattern="%Y-%m-%d", returnStr=False):
    """converts a string into a Python date time object or reformat existing datetime object

    Args:
        value (string): value to be converted
        pattern (str, optional): date format to be returned if returnStr. Defaults to '%m-%d-%Y'.
        returnStr (bool, optional): return string? if False returns a date time object. Defaults to False.

    Returns:
        datetime object if returnStr is False
        formatted string (following pattern) if returnStr is True
    """
    date = value if isinstance(value, datetime) else parse_date(value, fuzzy=True)
    return date.strftime(pattern) if returnStr else date


def to_bool(val, int_as_bool: bool=True):
    """Convert a string representation of truth to true or false.
    True values are 'y', 'yes', 't', 'true', 'on', and '1'; false values
    are 'n', 'no', 'f', 'false', 'off', and '0'.  Raises ValueError if
    'val' is anything else.
    modified from https://stackoverflow.com/a/18472142
    """
    true_values =  ["y", "yes", "t", "true"]
    if int_as_bool: true_values += ["1"]
    false_values = ["n", "no", "f", "false"]
    if int_as_bool: false_values += ["0"]

    if val.lower() in true_values:
        return True
    elif val.lower() in false_values:
        return False
    else:
        raise ValueError("Invalid boolean value %r" % (val,))


def is_bool(value, int_as_bool: bool = True):
    """checks if value is a boolean"""
    if isinstance(value, bool):
        return True

    try:
        to_bool(value, int_as_bool)
        return True
    except:
        return False


def is_date(value, fuzzy=False):
    """Return whether the string can be interpreted as a date.
    from https://stackoverflow.com/a/25341965

    Args:
        value (str): string to check for date
        fuzzy (bool, optional):ignore unknown tokens in string if True. Defaults to False.

    Returns:
        bool: flag indicating if string is date (or contains date if fuzzy=True)
    """
    if is_numeric(value):  # catch ints and floats
        return False

    if isinstance(value, datetime):
        return True

    try:
        parse_date(value, fuzzy=fuzzy)
        return True

    except:
        return False


def is_numeric(value):
    """legacy for `is_number`"""
    return is_number(value)


def is_number(value):
    """check if the string is a number;
    support legacy code originally written for Python 2.7"""
    # extra is_float if string is to check for scientific notation
    return (
        value.isnumeric() or is_float(value)
        if isinstance(value, str)
        else is_integer(value) or is_float(value)
    )


def is_integer(value):
    """check if the string is an integer"""
    if isinstance(value, (float, bool)):
        return False
    try:
        int(value)
        return True
    except ValueError:
        return False


def to_json(s: str) -> dict:
    """tests to see if a string is JSON and optionally returns converted string"""
    try:
        return json.loads(s)
    except (ValueError, TypeError):
        return s


def is_float(value):
    """check if the string is a float"""
    try:
        float(value)
        return True
    except ValueError:
        return False


def is_non_numeric(value):
    """checks if string is non-numeric; legacy to support code written for Python 2.7"""
    return not is_number(value)


def to_number(value):
    """convert string to appropriate number"""
    try:
        return int(value)
    except ValueError:
        return (
            int(float(value)) if float(value).is_integer() else float(value)
        )  # raises ValueError again that will be thrown


def to_numeric(value):
    """legacy  `to_number`"""
    return to_number(value)


def is_null(value: str, naIsNull: bool = False):
    """
    check to see if string contains a value that could be interpreted as null/undefined

    Args:
        value (str): string value to check
        naIsNull (bool, optional): flag if `NA` values should be interpreted as `NULL`. Defaults to False.

    Returns:
        bool: True if value is_null
    """
    if value is None or value in ["NULL", "null"]:
        return True
    if naIsNull and string_in_list(
        value,
        ["NA", "not reported", "not applicable", ".", "N/A", "NULL"],
        ignoreCase=True,
    ):
        return True
    return False


def is_camel_case(s):
    """relaxed check for camel case b/c allows things like cRGB"""
    return s != s.lower() and s != s.upper() and "_" not in s

def to_camel_case(s: str) -> str:
    return ''.join(word.capitalize() for word in s.split('_'))


def to_snake_case(key):
    """converts camel case or space delimited strings to snake case
    from https://stackoverflow.com/a/1176023 / advanced cases"""
    return regex_replace("([a-z0-9])([A-Z])", r"\1_\2", key).lower().replace(" ", "_")


def int_to_alpha(value, lower=False):
    """Convert an input integer to alphabetic representation,
    starting with 1=A. or 1=a if lower=True"""

    if lower:
        return chr(96 + value)
    else:
        return chr(64 + value)


def ascii_safe_str(obj):
    """convert to ASCII safe string"""
    try:
        return str(obj)
    except UnicodeEncodeError:
        return obj.encode("ascii", "ignore").decode("ascii")


def is_balanced(value, start="(", end=")"):
    """returns True if enclosing tags are balanced (e.g, braces, brackets, parentheses, carets, user defined)
    modified from https://www.geeksforgeeks.org/identify-mark-unmatched-parenthesis-expression/

    TODO: (possibly) handle multiple, nested kinds of tags, e.g., ([{}])

    Args:
        value (str): string to check

    Returns:
        boolean indicating whether or not parentheses are balanced
    """
    stack = []
    for c in value:
        # if c is opening tag then push into stack
        if c == start:
            stack.append(c)
        elif c == end:
            # unmatched start tag; return False
            if len(stack) == 0:
                return False
            else:  # matched start tag
                stack.pop()

    if len(stack) == 0:  # balanced
        return True
    else:  # not balanced
        return False


# regex wrappers to re calls to reduce re imports
# =================================================
def regex_replace(pattern, replacement, value, **kwargs) -> str:
    """
    wrapper for `re.sub`

    Args:
        pattern (str): regular expression pattern to match
        replacement (str):string to substitute for pattern
        value (str): original string
        **kwargs (optional): optional keyword arguments expected by `re.sub`:
            `count`: maximum number of patterns to be replaced
            `flags`: (e.g., IGNORECASE)
                see https://docs.python.org/3/library/re.html#re.RegexFlag;
                can import from `niagads.utils.RegexFlag`
                Defaults to NOFLAG (0).

    Returns:
        updated string
    """
    return re.sub(pattern, replacement, value, **kwargs)


def regex_extract(
    pattern, value, firstMatchOnly=True, **kwargs
) -> Union[str | List[str]]:
    """
    wrapper for `re.search`

    Args:
        pattern (str): regular expression pattern to match
        value (str): string to search
        **kwargs (optional): optional keyword arguments expected by `re.search`:
            `flags`: (e.g., IGNORECASE)
                see https://docs.python.org/3/library/re.html#re.RegexFlag;
                can import from `niagads.utils.RegexFlag`
                Defaults to NOFLAG (0).

    Returns:
        string containing first match if firstMatchOnly, else list of all pattern matches
    """
    if firstMatchOnly:
        result = re.search(pattern, value, **kwargs)

        if result is not None:
            try:
                return result.group(1)
            except:
                return result.group()
        return None

    else:
        result = re.findall(pattern, value, **kwargs)
        return None if len(result) == 0 else result


def matches(pattern, value, **kwargs) -> bool:
    """
    checks if string contains a pattern

    Args:
        pattern (str): regular expression pattern to match
        value (str): string to search
        **kwargs (optional): optional keyword arguments expected by `re.search`:
            `flags`: (e.g., IGNORECASE)
                see https://docs.python.org/3/library/re.html#re.RegexFlag;
                can import from `niagads.utils.RegexFlag`
                Defaults to NOFLAG (0).

    Returns:
        True if match is found
    """
    result = re.search(pattern, value, **kwargs)
    return result is not None


def regex_split(pattern, value, **kwargs):
    """
    wrapper for `re.split`

    Args:
        pattern (str): regular expression pattern to match
        value (str): string to search
        **kwargs (optional): optional keyword arguments expected by `re.split`:
            `maxsplit`: if maxsplit is non-zero than at most, maxsplit splits will be done
            `flags`: (e.g., IGNORECASE)
                see https://docs.python.org/3/library/re.html#re.RegexFlag;
                can import from `niagads.utils.RegexFlag`
                Defaults to NOFLAG (0).

    """
    return re.split(pattern, value, **kwargs)
