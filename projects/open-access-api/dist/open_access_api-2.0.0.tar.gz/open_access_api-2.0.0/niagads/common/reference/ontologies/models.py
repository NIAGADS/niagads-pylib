from typing import Any, Optional, Set, Union

from niagads.common.models.base import CustomBaseModel
from niagads.utils.regular_expressions import RegularExpressions
from niagads.utils.string import dict_to_info_string, matches
from pydantic import BaseModel, Field, ValidationInfo, field_validator, model_validator


class OntologyTerm(CustomBaseModel):
    """Basic ontology term identifiers"""

    curie: Optional[str] = Field(default=None, description="unique, stable identifier")
    term: str = Field(..., description="the ontology term")

    @classmethod
    def extract_from_obj(
        cls, value: Any, *, as_dict: bool = False
    ) -> Union[list["OntologyTerm"], list[dict]]:
        """Extract all formally defined OntologyTerm objects from a Pydantic Model and nested models.

        Returns unique list of OntologyTerms or dict of {term, curie} objs if as_dict is true
        """
        terms = cls.__extract_from_obj(value)

        if as_dict:
            return [{"term": term, "curie": curie} for term, curie in terms]

        return [OntologyTerm(term=term, curie=curie) for term, curie in terms]

    @classmethod
    def __extract_from_obj(cls, value: Any):
        """
        Internal recursive call for extract from obj
        """
        terms: Set[tuple] = set()

        if value is None:
            return terms
        if isinstance(value, OntologyTerm):
            terms.add((value.term, value.curie))
        elif isinstance(value, BaseModel):
            for field_name in value.__class__.model_fields:
                terms.update(cls.__extract_from_obj(getattr(value, field_name, None)))
        elif isinstance(value, dict):
            for item in value.values():
                terms.update(cls.__extract_from_obj(item))
        elif isinstance(value, (list, tuple, set)):
            for item in value:
                terms.update(cls.__extract_from_obj(item))

        return terms


class OntologyTermRecord(OntologyTerm):
    """
    Pydantic model representing a term in an ontology graph.

    Used for storing ontology term metadata, including category, label,
    definition, synonyms, and obsolescence information.
    """

    term_iri: Optional[str] = Field(
        default=None,
        description="globally unique identifier for the ontology term (URI)",
    )

    label: Optional[str] = Field(
        default=None, description="Human-readable label for the term"
    )
    definition: Optional[str] = Field(
        default=None, description="Textual definition of the term"
    )
    namespace: Optional[str] = Field(default=None, title="Namespace")
    synonyms: Optional[list[str]] = Field(
        default=None, description="List of synonyms for the term"
    )
    is_deprecated: Optional[bool] = Field(
        default=None, description="True if the term is deprecated"
    )
    is_placeholder: Optional[bool] = Field(
        default=None, description="True if palceholder term"
    )

    @staticmethod
    def extract_curie(iri: str) -> str:
        return iri.rsplit("/", 1)[-1].replace("_", ":")

    @field_validator("curie", mode="before")
    def validate_curie(cls, v, info: ValidationInfo):
        """
        Validate ID for the ontology term. If curie is None,
        extracts it from the URI. Raises a validation error if both are None.
        """
        if v is not None:
            return v
        term_iri: str = info.data.get("term_iri")
        if term_iri:
            return cls.extract_curie(term_iri)

        raise ValueError(
            "Either 'curie' or 'term_iri' must be provided for OntologyTerm."
        )

    @model_validator(mode="before")
    def normalize_field_values(cls, values: Union[str, dict]):
        """
        Converts all non-boolean field values to strings before model validation.

        Args:
            values (dict): Dictionary of field values.

        Returns:
            dict: Updated field values with non-boolean values converted to strings.
        """

        # if trying to serialize a string as an ontology term, assume
        # it is the term or curie
        if isinstance(values, str):
            if matches(values, RegularExpressions.ONTOLOGY_TERM_CURIE):
                curie = values.replace("_", ":")
                return cls(curie=curie, term=curie)
            return cls(term=values)

        for field, v in values.items():
            if isinstance(values, list):
                continue  # synonyms, probably
            if v is not None and not isinstance(v, bool):
                if field == "curie":
                    values[field] = str(v).replace("_", ":")
                else:
                    values[field] = str(v)
        return values

    def __str__(self):
        return self.term

    def to_info_string(self) -> str:
        info: dict = {"term": self.term}
        if self.curie:
            info.update({"curie": self.curie})
        return dict_to_info_string(info)
