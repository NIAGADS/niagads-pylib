"""Database session management"""

import logging
from asyncio import current_task
from contextlib import asynccontextmanager

import asyncpg
from asyncpg.transaction import Transaction
from niagads.exceptions.core import AbstractMethodNotImplemented, ValidationError
from sqlalchemy import Select, text
from sqlalchemy.dialects import postgresql
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_scoped_session,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool.base import PoolProxiedConnection
from sqlalchemy_utils.expressions import row_to_json

CONNECTION_POOL_SIZE = 10
POOL_RECYCLE = 1800  # 30 minutes

# Enable SQL compilation caching for sqlalchemy-utils' row_to_json;
# its SQL depends only on arguments covered by GenericFunction's cache key.
row_to_json.inherit_cache = True


class DatabaseSessionManager:
    """Dependency for managing database session target based on endpoint
    adapted from: https://dev.to/akarshan/asynchronous-database-sessions-in-fastapi-with-sqlalchemy-1o7e
    """

    def __init__(
        self,
        connection_string: str,
        pool_size: int = CONNECTION_POOL_SIZE,
        max_connection_lifetime: int = POOL_RECYCLE,
        echo: bool = False,
        expire_on_commit: bool = True,
    ):
        """Initialize DatabaseSessionManager object.

        Args:
            connectionString (str): database URI in postgresql://[user[:password]@][netloc][:port][/dbname][?param1=value1&...] format
            connectionPoolSize (int): connection pool size. Defaults to 10
        """
        self.__engine: AsyncEngine = create_async_engine(
            self.__get_async_uri(connection_string),
            echo=echo,  # Log SQL queries for debugging (set to False in production)
            pool_size=pool_size,  # Maximum number of permanent connections to maintain in the pool
            max_overflow=10,  # Maximum number of additional connections that can be created if the pool is exhausted
            pool_timeout=30,  # Number of seconds to wait for a connection if the pool is exhausted
            pool_recycle=max_connection_lifetime,  # Maximum lifetime (in seconds) of a connection before it is closed and replaced (prevents stale connections)
        )

        self.__sessionMaker: async_sessionmaker = async_sessionmaker(
            bind=self.__engine, expire_on_commit=expire_on_commit
        )
        self.__session: AsyncSession = async_scoped_session(
            self.__sessionMaker, scopefunc=current_task
        )
        self.logger = logging.getLogger(__name__)
        logging.getLogger("sqlalchemy").setLevel(logging.ERROR)  # turn off INFO logging
        logging.getLogger("sqlalchemy.engine").setLevel(
            logging.ERROR
        )  # turn off INFO logging

    def __get_async_uri(self, uri: str = None) -> str:
        """Convert a standard PostgreSQL URI to an asyncpg-compatible URI.

        Args:
            uri (str, optional): The PostgreSQL URI. Defaults to None.

        Returns:
            str: The asyncpg-compatible PostgreSQL URI.
        """
        return uri.replace("postgresql:", "postgresql+asyncpg:").replace(
            "postgres:",  # in case of copy paste from tsh connection string
            "postgresql+asyncpg:",
        )

    @property
    def engine(self) -> AsyncEngine:
        """Get the SQLAlchemy async engine.

        Returns:
            AsyncEngine: The SQLAlchemy async engine instance.
        """
        return self.__engine

    async def test_connection(self) -> bool:
        """Test the database connection by executing a simple SELECT 1 query.

        Returns:
            bool: True if the connection is successful.

        Raises:
            OSError: If the connection test fails.
        """
        try:
            async with self.__engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            return True
        except Exception as err:
            self.logger.error(
                "Database connection test failed", exc_info=True, stack_info=True
            )
            raise OSError(f"Database connection test failed: {str(err)}")

    async def close(self) -> None:
        """Close all pooled connections and reset the connection pool.

        Raises:
            Exception: If the engine is not initialized.
        """
        if self.__engine is None:
            raise Exception("DatabaseSessionManager is not initialized")
        await self.__engine.dispose()

    @asynccontextmanager
    async def raw_connection_ctx(self):
        """Provide a raw asyncpg connection with explicit transaction control.

        Bypasses SQLAlchemy's prepared statement protocol, allowing execution
        of multi-statement SQL strings and `$$`-quoted procedural blocks
        (e.g., PL/pgSQL function definitions).

        A transaction is started before the connection is yielded. The
        transaction is rolled back when the context exits unless the caller
        explicitly commits it. This prevents raw statements from being
        autocommitted and makes accidental writes non-persistent.

        Yields:
            tuple[asyncpg.Connection, asyncpg.transaction.Transaction]: The
                underlying asyncpg driver connection and its active
                transaction.

        Raises:
            RuntimeError: If the engine is not initialized.

        Example:
            async with manager.raw_connection() as (conn, transaction):
                await conn.execute(sql)
                await transaction.commit()  # omit to roll back on exit
        """
        self.logger.warning(
            "Using RAW CONNECTION - changes require an explicit transaction commit"
        )
        if self.__engine is None:
            raise RuntimeError("DatabaseSessionManager is not initialized")

        async with self.__engine.connect() as conn:
            raw: PoolProxiedConnection = await conn.get_raw_connection()
            connection: asyncpg.Connection = raw.driver_connection
            transaction: Transaction = connection.transaction()
            await transaction.start()

            try:
                yield connection, transaction
            except BaseException:
                if connection.is_in_transaction():
                    await transaction.rollback()
                raise
            else:
                if connection.is_in_transaction():
                    await transaction.rollback()

    @asynccontextmanager
    async def session_ctx(self):
        """
        Provide an async context manager for a SQLAlchemy async session.

        Attaches an after_flush listener to automatically track per-table inserts,
        updates, and deletes. Tracking is stored on session._etl_tracking and
        accumulates across multiple flushes in the same session.

        Yields:
            AsyncSession: An active SQLAlchemy async session.

        Raises:
            RuntimeError: If the session manager is not initialized.

        Example:
            async with manager.session_ctx() as session:
                await session.execute(...)
        """
        session: AsyncSession  # annotated type hint
        async with self.__session() as session:
            if session is None:
                raise RuntimeError("DatabaseSessionManager is not initialized")

            try:
                yield session

            finally:
                if hasattr(session, "in_transaction") and session.in_transaction():
                    await session.rollback()
                if session.is_active:
                    await session.close()

    @classmethod
    def compile_select_statement(self, stmt: Select):
        """Compile a SQLAlchemy SELECT statement with literal bind values.

        Args:
            stmt (Select): The SQLAlchemy SELECT statement to compile.

        Returns:
            str: The PostgreSQL SQL statement with bound values embedded.
        """
        return str(
            stmt.compile(
                dialect=postgresql.dialect(),
                compile_kwargs={"literal_binds": True},
            )
        )

    async def __call__(self):
        """Provide an async database session; cannot be used as a context manager.

        Yields:
            AsyncSession: The SQLAlchemy async session.

        Raises:
            OSError: For database connection errors.
            RuntimeError: For errors propogated up from calling functions.
        """
        session: AsyncSession  # annotated type hint
        async with self.__session() as session:
            if session is None:
                raise RuntimeError("DatabaseSessionManager is not initialized")

            try:
                yield session

            except (
                NotImplementedError,
                AbstractMethodNotImplemented,
                ValidationError,
                RuntimeError,
            ) as err:
                if isinstance(err, AbstractMethodNotImplemented):
                    raise NotImplementedError(str(err))
                else:
                    raise err

            except (
                asyncpg.InvalidPasswordError,
                ConnectionRefusedError,
                ConnectionError,
            ) as err:
                self.logger.error("Database Error", exc_info=True, stack_info=True)
                raise OSError(f"Database Error: {str(err)}")

            except Exception as err:
                if "HTTPException" in type(err).__name__ or getattr(
                    err, "status_code", False
                ):
                    raise err  # will be handled by API
                # everything else for which we currently have no handler
                if "Connection refused" in str(err) or "Connection" in str(type(err)):
                    # don't want to create dependency to redis in this module
                    # so checking message instead of exception type
                    self.logger.error("Database Error", exc_info=True, stack_info=True)
                    raise OSError(f"Database Error: {str(err)}")

                self.logger.error("Unexpected Error", exc_info=True, stack_info=True)
                raise RuntimeError(f"Unexpected Error: {str(err)}")

            finally:
                # Only rollback if transaction is active and session is not closed
                if hasattr(session, "in_transaction") and session.in_transaction():
                    await session.rollback()
                if session.is_active:
                    await session.close()
