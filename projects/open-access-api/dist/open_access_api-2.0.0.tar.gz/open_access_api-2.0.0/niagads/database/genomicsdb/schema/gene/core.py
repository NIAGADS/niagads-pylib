# this set up is necessary for Alembic to import all the models associated with the metadata schema
# see https://stackoverflow.com/a/77767002
#  FIXME: can I just use __init__.py?

from niagads.database.genomicsdb.schema.gene.annotation import PathwayMembership
from niagads.database.genomicsdb.schema.gene.documents import Gene
from niagads.database.genomicsdb.schema.gene.structure import (
    ExonModel,
    GeneModel,
    TranscriptModel,
)
from niagads.database.genomicsdb.schema.gene.xrefs import GeneXRef
