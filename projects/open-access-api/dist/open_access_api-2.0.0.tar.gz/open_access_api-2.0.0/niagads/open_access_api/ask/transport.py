"""AI SDK streaming route on the existing application, with bounded input."""

import asyncio
import json
import logging
from contextlib import nullcontext
from uuid import uuid4

import httpx
import logfire
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.openapi.utils import get_openapi
from niagads.open_access_api.ask.agent import build_agent
from niagads.open_access_api.ask.config import AskSettings
from niagads.open_access_api.ask.contracts import AskIssue, AskResponse
from niagads.open_access_api.ask.feedback import (
    AskFeedback,
    create_feedback_reference,
    record_feedback,
)
from niagads.open_access_api.ask.planning import build_query_planner
from niagads.open_access_api.ask.results import ResultStore
from pydantic_ai.ui.vercel_ai import VercelAIAdapter
from pydantic_ai.ui.vercel_ai.response_types import DataChunk, ErrorChunk, StartChunk
from pydantic_ai.usage import RunUsage, UsageLimits
from starlette.responses import Response, StreamingResponse

router = APIRouter(tags=["ASK NIAGADS"])


def sanitize_history(payload: dict) -> dict:
    """Accept bounded text history only; client tool outputs are never evidence."""
    messages = payload.get("messages")
    if not isinstance(messages, list) or not 1 <= len(messages) <= 12:
        raise ValueError("Supply 1 to 12 conversation messages")
    clean = []
    size = 0
    for message in messages:
        if not isinstance(message, dict) or message.get("role") not in {
            "user",
            "assistant",
        }:
            raise ValueError("Only user and assistant text history is accepted")
        parts = message.get("parts", [])
        if not isinstance(parts, list):
            raise ValueError("Message parts must be a list")
        texts = []
        for part in parts:
            if not isinstance(part, dict):
                raise ValueError("Invalid message part")
            if part.get("type") != "text":
                if message["role"] == "user":
                    raise ValueError("Only text queries are supported")
                continue
            text = part.get("text")
            if not isinstance(text, str):
                raise ValueError("Message text must be a string")
            size += len(text)
            if len(text) > 8000 or size > 16000:
                raise HTTPException(
                    413,
                    "This conversation is too long. "
                    "Start a new session with a shorter question.",
                )
            texts.append({"type": "text", "text": text})
        if texts:
            clean.append({"id": str(uuid4()), "role": message["role"], "parts": texts})
    if not clean or clean[-1]["role"] != "user":
        raise ValueError("The final message must contain a user question")
    return {"id": str(uuid4()), "messages": clean, "trigger": "submit-message"}


def get_settings() -> AskSettings:
    """Load optional assistant configuration without changing existing API settings."""
    try:
        return AskSettings()
    except ValueError as exc:
        raise RuntimeError(
            f"ASK configuration failed: {type(exc).__name__}: {exc}"
        ) from exc


def get_agent(settings: AskSettings = Depends(get_settings)):
    """Provide an injectable model agent; configuration errors are actionable."""
    try:
        return build_agent(settings)
    except ValueError as exc:
        raise RuntimeError(
            f"ASK agent initialization failed: {type(exc).__name__}: {exc}"
        ) from exc


def get_api_transport(request: Request) -> httpx.AsyncBaseTransport:
    """Reuse this application's registered API routes, preserving its boundaries."""
    return httpx.ASGITransport(app=request.app)


@router.post("/ask/feedback", status_code=204, operation_id="submitAskFeedback")
async def submit_feedback(
    feedback: AskFeedback,
    request: Request,
    settings: AskSettings = Depends(get_settings),
) -> Response:
    secret = getattr(request.app.state, "ask_feedback_signing_secret", None)
    if (
        not getattr(request.app.state, "ask_telemetry_enabled", False)
        or not settings.feedback_enable
        or secret is None
    ):
        raise HTTPException(503, "Feedback is currently unavailable")
    try:
        record_feedback(feedback, secret)
    except ValueError as exc:
        raise HTTPException(422, "Invalid feedback reference") from exc
    return Response(status_code=204)


@router.post(
    "/ask",
    summary="Ask NIAGADS",
    operation_id="askNiagads",
    openapi_extra={"x-status": "alpha"},
)
async def ask(
    request: Request,
    agent=Depends(get_agent),
    transport=Depends(get_api_transport),
    settings: AskSettings = Depends(get_settings),
) -> StreamingResponse:
    """Stream grounded text and complete result parts; no database code lives here."""
    raw = bytearray()
    async for chunk in request.stream():
        raw.extend(chunk)
        if len(raw) > 65536:
            raise HTTPException(
                413, "The conversation is too long. Start a new session."
            )
    try:
        payload = json.loads(raw)
        if not isinstance(payload, dict):
            raise ValueError("Expected a conversation object")
        clean = sanitize_history(payload)
        run_input = VercelAIAdapter.build_run_input(json.dumps(clean).encode())
    except (ValueError, TypeError) as exc:
        raise HTTPException(
            422,
            f"Invalid conversation: {type(exc).__name__}: {exc}",
        ) from exc
    adapter = VercelAIAdapter(agent=agent, run_input=run_input, sdk_version=7)
    store = ResultStore()
    # API help needs registered operations, not unrelated application server metadata.
    spec = get_openapi(
        title="ASK NIAGADS operation catalog",
        version="prototype",
        routes=request.app.routes,
    )
    deps = {"store": store, "spec": spec, "warnings": [], "failures": [], "issues": []}

    result_sent = False
    feedback_reference = None
    feedback_secret = getattr(request.app.state, "ask_feedback_signing_secret", None)
    feedback_enabled = bool(
        getattr(request.app.state, "ask_telemetry_enabled", False)
        and settings.feedback_enable
        and feedback_secret is not None
    )

    async def complete(result, failed: bool = False):
        nonlocal result_sent
        if result_sent:
            return
        status = (
            "retrieval_error"
            if failed
            else (
                deps["failures"][0]
                if deps["failures"]
                else (
                    "empty"
                    if store.results and not any(r.rows for r in store.results.values())
                    else "ok"
                )
            )
        )
        envelope = AskResponse(
            feedback_reference=feedback_reference,
            status=status,
            results=list(store.results.values()),
            presentation=store.presentations,
            warnings=list(dict.fromkeys(deps["warnings"])),
            issues=list(
                {issue.model_dump_json(): issue for issue in deps["issues"]}.values()
            ),
        )
        result_sent = True
        yield DataChunk(
            type="data-niagads-result", data=envelope.model_dump(mode="json")
        )

    async def stream():
        nonlocal feedback_reference
        message_started = False
        headers = {
            name: request.headers[name]
            for name in ("authorization", "cookie", "x-request-id")
            if name in request.headers
        }
        headers.setdefault("x-request-id", str(uuid4()))
        with (
            logfire.span("ASK NIAGADS response") if feedback_enabled else nullcontext()
        ):
            if feedback_enabled:
                feedback_reference = create_feedback_reference(feedback_secret)
            try:
                async with asyncio.timeout(settings.deadline):
                    async with httpx.AsyncClient(
                        transport=transport,
                        base_url="http://niagads.internal",
                        headers=headers,
                        timeout=settings.api_timeout,
                    ) as client:
                        deps["client"] = client
                        usage = RunUsage()
                        usage_limits = UsageLimits(
                            request_limit=settings.model_requests,
                            tool_calls_limit=settings.tool_calls,
                            input_tokens_limit=20000,
                            output_tokens_limit=12000,
                        )
                        planned = await build_query_planner(agent.model).run(
                            json.dumps(clean["messages"]),
                            usage=usage,
                            usage_limits=usage_limits,
                        )
                        deps["query_plan"] = planned.output
                        if planned.output.clarifications:
                            deps["failures"].append("clarification")
                        if planned.output.exclusions:
                            deps["failures"].append("unsupported")
                            deps["issues"].append(
                                AskIssue(
                                    code="unsupported",
                                    operation="query_planning",
                                    message="Exclusions are deferred and have not been applied.",
                                )
                            )
                        native_events = adapter.run_stream_native(
                            deps=deps,
                            usage=usage,
                            usage_limits=usage_limits,
                        )

                        async def observed_events():
                            try:
                                async for event in native_events:
                                    yield event
                            except Exception:
                                logging.getLogger(
                                    "uvicorn.error.niagads.ask"
                                ).exception(
                                    "ASK stream failed request_id=%s",
                                    headers["x-request-id"],
                                )
                                raise

                        events = adapter.transform_stream(
                            observed_events(), on_complete=complete
                        )

                        async def stream_events():
                            nonlocal message_started
                            yield DataChunk(
                                type="data-niagads-plan",
                                data=planned.output.model_dump(mode="json"),
                            )
                            async for event in events:
                                if isinstance(event, StartChunk):
                                    message_started = True
                                if isinstance(event, ErrorChunk):
                                    if not message_started and feedback_reference:
                                        yield StartChunk(message_id=str(uuid4()))
                                        message_started = True
                                    if store.results or feedback_reference:
                                        async for result_event in complete(
                                            None, failed=True
                                        ):
                                            yield result_event
                                    event.error_text += (
                                        f" Reference: {headers['x-request-id']}."
                                    )
                                yield event

                        async for event in adapter.encode_stream(stream_events()):
                            yield event
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logging.getLogger("uvicorn.error.niagads.ask").exception(
                    "ASK stream failed request_id=%s", headers["x-request-id"]
                )
                if not message_started and feedback_reference:
                    event = StartChunk(message_id=str(uuid4()))
                    yield "data: " + event.model_dump_json(by_alias=True) + "\n\n"
                if store.results or feedback_reference:
                    async for event in complete(None, failed=True):
                        yield "data: " + event.model_dump_json(by_alias=True) + "\n\n"
                event = ErrorChunk(
                    errorText=(
                        f"{type(exc).__name__}: {exc} "
                        f"Reference: {headers['x-request-id']}."
                    )
                )
                yield "data: " + event.model_dump_json(by_alias=True) + "\n\n"
                yield "data: [DONE]\n\n"

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={"x-vercel-ai-ui-message-stream": "v1", "Cache-Control": "no-cache"},
    )
