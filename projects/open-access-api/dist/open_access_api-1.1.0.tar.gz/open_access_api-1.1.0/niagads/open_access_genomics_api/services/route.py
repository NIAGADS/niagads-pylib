from typing import Optional

from fastapi import HTTPException
from niagads.common.models.structures import Range
from niagads.database.schemas.dataset.track import Track, TrackDataStore
from niagads.exceptions.core import ValidationError
from niagads.open_access_api_common.models.features.feature_score import (
    GWASSumStatResponse,
    QTLResponse,
)
from niagads.open_access_api_common.models.services.query import (
    QueryDefinition,
    QueryFilter,
)
from niagads.open_access_api_common.parameters.internal import InternalRequestParameters
from niagads.open_access_api_common.parameters.response import ResponseContent
from niagads.open_access_api_common.services.metadata.query import MetadataQueryService
from niagads.open_access_api_common.services.metadata.route import (
    MetadataRouteHelperService,
)
from niagads.open_access_api_common.services.route import (
    Parameters,
    ResponseConfiguration,
)

from niagads.open_access_genomics_api.queries.track_data import (
    TrackGWASSumStatQuery,
    TrackQTLGeneQuery,
)
from niagads.utils.dict import all_values_are_none
from pydantic import BaseModel
from sqlalchemy import bindparam, text
from sqlalchemy.exc import NoResultFound


class QueryOptions(BaseModel):
    fetchOne: Optional[bool] = False
    countsOnly: Optional[bool] = False
    rawResponse: Optional[bool] = False
    range: Optional[Range] = None


class GenomicsRouteHelper(MetadataRouteHelperService):

    def __init__(
        self,
        managers: InternalRequestParameters,
        responseConfig: ResponseConfiguration,
        params: Parameters,
        query: QueryDefinition = None,
        idParameter: str = "id",
    ):
        super().__init__(
            managers,
            responseConfig,
            params,
            [TrackDataStore.SHARED, TrackDataStore.GENOMICS],
        )
        self.__query = query
        self.__idParameter: str = idParameter

    def __build_counts_statement(self):
        isFiltered = (
            self.__query.allowFilters and self._parameters.get("filter") is not None
        )
        filter: QueryFilter = self._parameters.get("filter")

        if self.__query.countsQuery != None:
            statement = text(self.__query.countsQuery)
            parameters = [bindparam("id", self._parameters.get(self.__idParameter))]
            statement = statement.bindparams(*parameters)
        else:
            statement = (
                self.__query.get_filter_query(filter)
                if isFiltered
                else self.__query.query
            )
            statement = text(f"SELECT count(*) AS result_size FROM ({statement}) r")
            parameters = [
                bindparam(
                    param,
                    (
                        self._parameters.get(self.__idParameter)
                        if param == "id"
                        else self._parameters.get(param)
                    ),
                )
                for param in self.__query.bindParameters
            ]

            if isFiltered:
                parameters.append(bindparam("filter", filter.value))

            statement = statement.bindparams(*parameters)

        return statement

    def __build_statement(self, opts: QueryOptions):
        if opts.countsOnly:
            statement = self.__build_counts_statement()
        else:
            isFiltered = (
                self.__query.allowFilters and self._parameters.get("filter") is not None
            )
            filter: QueryFilter = self._parameters.get("filter")

            query: str = (
                self.__query.get_filter_query(filter)
                if isFiltered
                else self.__query.query
            )

            if self.__query.jsonField is not None:
                query = query.format(field=self.__query.jsonField)

            if opts.range is not None:
                if "rank_start" not in self.__query.bindParameters:
                    query += f" LIMIT {self._pageSize}"
                    query += f" OFFSET {opts.range.end}"

            statement = text(query)

            if self.__query.bindParameters is not None:
                # using the binparam object allows us to use the same parameter multiple times
                # which is not possible w/simple dict representaion
                parameters = []
                for param in self.__query.bindParameters:
                    if param == "id":
                        parameters.append(
                            bindparam(param, self._parameters.get(self.__idParameter))
                        )
                    elif param == "rank_start":
                        parameters.append(
                            bindparam(
                                param, 0 if opts.range is None else opts.range.start
                            )
                        )
                    elif param == "rank_end":
                        parameters.append(
                            bindparam(
                                param,
                                (
                                    self._pageSize - 1
                                    if opts.range is None
                                    else opts.range.end
                                ),
                            )
                        )
                    else:
                        parameters.append(bindparam(param, self._parameters.get(param)))

                if isFiltered:
                    parameters.append(bindparam("filter", filter.value))
                statement = statement.bindparams(*parameters)
            else:
                if isFiltered:
                    parameters = [bindparam("filter", filter.value)]
                    statement = statement.bindparams(*parameters)
        return statement

    async def __run_query(self, opts: QueryOptions):
        statement = self.__build_statement(opts)
        try:
            # .mappings() returns result as dict
            result = (await self._managers.session.execute(statement)).mappings().all()

            if len(result) == 0:
                raise NoResultFound()

            if all_values_are_none(result[0]):
                if self.__query.jsonField is not None:
                    # valid record, no data for field
                    return []
                raise NoResultFound()

            if self.__query.fetchOne or opts.fetchOne or opts.countsOnly:
                if self.__query.jsonField:
                    result = result[0][self.__query.jsonField]
                    if isinstance(result, list):
                        return [dict(item) for item in result]
                    return [result]
                return [result[0]]
            else:
                # if self.__query.jsonField:
                #     filteredResult = [item[self.__query.jsonField] for item in result]

                return [dict(item) for item in result]

        except NoResultFound as e:
            if self.__query.entity is not None:
                raise HTTPException(
                    status_code=404, detail=f"{str(self.__query.entity)} not found"
                )
            if self.__query.fetchOne:
                return {}
            else:
                return []

    async def __get_paged_query_response(self):
        rSize = await self.__run_query(QueryOptions(countsOnly=True))
        self._resultSize = rSize["result_size"]
        self.initialize_pagination()
        return await self.get_query_response(
            QueryOptions(range=self.slice_result_by_page())
        )

    async def get_query_response(self, opts: QueryOptions = QueryOptions()):
        # fetchCounts ->  get counts only
        cachedResponse = await self._get_cached_response()
        if cachedResponse is not None:
            return cachedResponse

        result = await self.__run_query(opts)

        if opts.rawResponse:
            return result

        if not self.__query.fetchOne and isinstance(result, list):
            self._resultSize = len(result)
            if self._resultSize > 0:  # not empty
                self.initialize_pagination()
                range = self.slice_result_by_page()
                result = result[range.start : range.end]

        return await self.generate_response(result, False)

    async def __validate_track(self):
        result = await MetadataQueryService(
            self._managers.session, dataStore=self._dataStore
        ).get_track_metadata(tracks=[self._parameters.track])
        if len(result) == 0:
            raise ValidationError(
                "Track not found in the NIAGADS Alzheimer's GenomicsDB"
            )

        return result[0]

    async def get_track_data_query_response(self):
        cachedResponse = await self._get_cached_response()
        if cachedResponse is not None:
            return cachedResponse

        # this will both validate and allow us to determine which kind of track
        result: Track = await self.__validate_track()
        # result: GenomicsTrack = await self.__run_query(QueryOptions(fetchOne=True))

        match result.experimental_design["data_category"]:
            case "QTL":
                self.__query = TrackQTLGeneQuery
                if self._responseConfig.content == ResponseContent.FULL:
                    self._responseConfig.model = QTLResponse
            case _ if result.experimental_design["data_category"].startswith("GWAS"):
                self.__query = TrackGWASSumStatQuery
                if self._responseConfig.content == ResponseContent.FULL:
                    self._responseConfig.model = GWASSumStatResponse
            case _:
                raise RuntimeError(
                    f"Track with invalid type retrieved: {result.track_id} - {result.data_category}"
                )

        match self._responseConfig.content:
            case ResponseContent.BRIEF | ResponseContent.COUNTS:
                counts = await self.get_query_response(
                    QueryOptions(countsOnly=True, rawResponse=True)
                )
                suffix = (
                    "qtls"
                    if result.experimental_design["data_category"] == "QTL"
                    else "significant_associations"
                )
                if self._responseConfig.content == ResponseContent.COUNTS:
                    return await self.generate_response(
                        {f"num_{suffix}": counts["result_size"]}
                    )
                else:
                    result[f"num_{suffix}"] = counts["result_size"]
                    return await self.generate_response(result)
            case _:  # FULL
                return await self.__get_paged_query_response()
                # return await self.get_query_response()
