from niagads.assembly import core

__all__ = ["core"]
