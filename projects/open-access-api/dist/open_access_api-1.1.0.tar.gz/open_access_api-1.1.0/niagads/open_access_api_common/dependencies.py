def get_none():
    return None
