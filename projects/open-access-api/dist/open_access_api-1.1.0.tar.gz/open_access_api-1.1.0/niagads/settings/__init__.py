from niagads.settings import core

__all__ = ["core"]
