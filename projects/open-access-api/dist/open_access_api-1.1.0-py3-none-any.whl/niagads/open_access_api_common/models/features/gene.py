from typing import Dict, List, Optional, Union

from niagads.database.schemas.gene.composite_attributes import (
    GOAnnotation,
    PathwayAnnotation,
)
from niagads.open_access_api_common.models.core import RowModel
from niagads.open_access_api_common.models.features.genomic import GenomicRegion
from niagads.open_access_api_common.models.response.core import RecordResponse
from pydantic import Field


class GeneFeature(RowModel):
    id: str = Field(title="Ensembl ID", description="Ensembl gene identifier")
    gene_symbol: Optional[str] = Field(
        default=None,
        title="Gene Symbol",
        description="official gene symbol",
        serialization_alias="symbol",
    )

    def __str__(self):
        return self.id

    # should allow to fill from SQLAlchemy ORM model
    # model_config = ConfigDict(from_attributes=True, serialize_by_alias=True)


class Gene(GeneFeature):
    gene_type: Optional[str] = Field(default=None, serialization_alias="type")
    gene_name: Optional[str] = Field(default=None, serialization_alias="name")
    synonyms: Optional[List[str]] = Field(
        default=None, title="Aliases", descriptions="gene symbol synonyms or aliases"
    )
    location: GenomicRegion = Field(
        title="Location",
        description="genomic location delimiting the footprint (span) of the gene",
    )

    def __str__(self):
        return self.as_info_string()

    def _flat_dump(self, nullFree=False, delimiter="|"):
        obj = super()._flat_dump(nullFree, delimiter=delimiter)
        if self.synonyms is not None:
            obj["synonyms"] = self._list_to_string(self.synonyms, delimiter=delimiter)

        # promote the location fields
        del obj["location"]
        obj.update(self.location._flat_dump())
        return obj

    @classmethod
    def get_model_fields(cls, asStr=False):
        fields = super().get_model_fields()
        del fields["location"]
        fields.update(GenomicRegion.get_model_fields())

        return list(fields.keys()) if asStr else fields


class AnnotatedGene(Gene):
    hgnc_annotation: Optional[Dict[str, Union[str, int]]] = None
    go_annotation: Optional[List[GOAnnotation]] = None
    pathway_membership: Optional[List[PathwayAnnotation]] = None

    def as_info_string(self):
        raise NotImplementedError("Not implemented for Annotated Genes")

    def as_list(self, fields=None):
        raise NotImplementedError("Not implemented for Annotated Genes")

    def as_table_row(self, **kwargs):
        raise NotImplementedError("Not implemented for Annotated Genes")


class GeneFunction(GOAnnotation, RowModel):
    def __str__(self):
        return self.as_info_string()

    def _flat_dump(self, nullFree=False, delimiter="|"):
        obj = super()._flat_dump(nullFree, delimiter=delimiter)
        if self.evidence is not None:
            obj["evidence"] = self._list_to_string(self.evidence, delimiter=delimiter)
        return obj


class GenePathwayMembership(PathwayAnnotation, RowModel):
    def __str__(self):
        return self.as_info_string()


class GeneAnnotationResponse(RecordResponse):
    data: Union[
        List[GenePathwayMembership],
        List[GeneFunction],
        List[RowModel],
    ]


class AbridgedGeneResponse(RecordResponse):
    data: List[Gene]


class GeneResponse(RecordResponse):
    data: List[AnnotatedGene]

    def to_table(self, id=None, title=None):
        raise NotImplementedError("Table views not avaialble for `FULL` gene records.")

    def to_text(self, inclHeader=False, nullStr=None):
        raise NotImplementedError(
            "Plain text responses not available for `FULL` gene records."
        )
