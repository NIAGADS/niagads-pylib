from typing import Union

from fastapi import APIRouter, Depends
from niagads.api.common.constants import SharedOpenAPITags
from niagads.api.common.models.response.core import ListResponse, RecordResponse
from niagads.api.filer.dependencies import (
    InternalRequestParameters,
    TextSearchFilterFields,
)
from niagads.api.filer.documentation import BASE_TAGS

router = APIRouter(prefix="/dictionary", tags=BASE_TAGS)

tags = [str(SharedOpenAPITags.DICTIONARY)]


@router.get(
    "/filters",
    tags=tags,
    response_model=ListResponse,
    summary="get-text-search-filter-fields",
    description="List allowable fields for text search filter expressions.",
)
async def get_allowable_text_filters(
    internal: InternalRequestParameters = Depends(),
) -> ListResponse:

    return ListResponse(
        data=TextSearchFilterFields.list(toLower=True), request=internal.request_data
    )


# TODO values for each filter field
"""
@router.get(
    "/filters/{field}",
    tags=tags,
    response_model=Union[RecordResponse],
    summary="get-text-search-filter-fields",
    description="List allowable fields for text search filter expressions.",
)
async def get_allowable_text_filters(
    internal: InternalRequestParameters = Depends(),
) -> RecordResponse:

    return RecordResponse(
        data=TextSearchFilterFields.list(toLower=True), request=internal.requestData
    )
"""
