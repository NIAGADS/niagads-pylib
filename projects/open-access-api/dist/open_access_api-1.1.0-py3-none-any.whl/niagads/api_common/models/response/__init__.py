from niagads.api_common.models.response.core import (
    RecordResponse,
    T_RecordResponse,
)

__all__ = ["RecordResponse", "RecordResponse", "T_RecordResponse"]
